# Assets and licences

The five screen textures are current interactive-walkthrough captures copied by the mission director into `assets/static-*-desktop.png`. They show only synthetic or prepared examples, as their own pages label. The source turns each capture into a texture on a 3D monitor; it does not redraw or fabricate product-interface claims. `render.html` draws only the title, explanatory overlay and closing card plus geometric meshes. `three@0.181.0` is used under the MIT License; its bundled text is `THREE-MIT-LICENSE.txt`. Chromium and FFmpeg are execution tools only and are not embedded in the video.

The video includes no narration and no audio track, so it has no voice, music or sound-effect licence.

The five supplied textures are the final interactive captures for this render. Any replacement must record its origin and data classification before release.
