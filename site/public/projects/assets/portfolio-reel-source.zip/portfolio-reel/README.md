# Reproducible 3D recruiter reel

`output/cpl-recruiter-reel-56s.mp4` is a 56-second, 1280×720, 24 fps video. It has no audio or narration; `TRANSCRIPT.md` records every on-screen sentence. `output/cpl-recruiter-reel-poster.png` is the matching 1280×720 poster.

The source is a genuine WebGL scene. `render.html` builds five 3D monitor assemblies with depth, metallic frames, lighting, a floor grid and a moving perspective camera. Each monitor uses a supplied capture of its actual published walkthrough. It is not a CSS slideshow or a page animation recorded as the deliverable.

## Re-render

From this directory, use only the locally pinned dependencies:

```sh
npm ci
npm run capture
ffmpeg -y -i output/cpl-recruiter-reel-56s.webm -an -c:v libx264 -pix_fmt yuv420p -movflags +faststart -r 24 output/cpl-recruiter-reel-56s.mp4
npm run inspect
```

The capture is deterministic in content but is recorded in real time so WebGL's `captureStream(24)` can make an actual video stream. The Chromium invocation requests SwiftShader because the capture runs headlessly. The page only loads its local Three.js module; it makes no network request, tool call, account request or database connection.

## Truthful scope

The panels are synthetic, prepared explanatory states. ToolCall does not execute tools. Entity's value is a similarity, not a probability. PMR is a prepared preview because the frozen runtime is blocked. API Contract Guard shows pre-calculated reports for a defined subset. EvidenceDesk's prepared answer does not change its frozen v7 HONEST_NEGATIVE evaluation.
