import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
for (const file of ['cpl-recruiter-reel-56s.webm', 'cpl-recruiter-reel-56s.mp4', 'cpl-recruiter-reel-poster.png']) {
  const target = path.join(here, 'output', file);
  try { console.log(file); console.log(execFileSync('ffprobe',['-v','error','-show_entries','format=duration,size:stream=codec_name,width,height,r_frame_rate','-of','json',target],{encoding:'utf8'})); } catch { console.log('not present'); }
}
