import { mkdir, readFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { chromium } from 'playwright';

const here = path.dirname(fileURLToPath(import.meta.url));
const out = path.join(here, 'output');
await mkdir(out, { recursive: true });
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.json': 'application/json; charset=utf-8' };
const server = createServer(async (req, res) => {
  const pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname);
  const requested = path.resolve(here, `.${pathname === '/' ? '/render.html' : pathname}`);
  if (!requested.startsWith(`${here}${path.sep}`)) { res.writeHead(403).end(); return; }
  try { const body = await readFile(requested); res.writeHead(200, { 'content-type': types[path.extname(requested)] || 'application/octet-stream', 'cache-control': 'no-store' }); res.end(body); }
  catch { res.writeHead(404).end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const port = server.address().port;
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true, args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required', '--allow-file-access-from-files'] });
const context = await browser.newContext({ viewport: { width: 1280, height: 720 }, acceptDownloads: true });
const page = await context.newPage();
await page.goto(`http://127.0.0.1:${port}/render.html`, { waitUntil: 'networkidle' });
await page.waitForFunction(() => typeof window.captureReel === 'function', { timeout: 30_000 });
const downloadEvent = page.waitForEvent('download', { timeout: 0 });
const result = await page.evaluate(() => window.captureReel(56));
const download = await downloadEvent;
await download.saveAs(path.join(out, 'cpl-recruiter-reel-56s.webm'));
await page.evaluate(() => window.renderAt(52));
await page.screenshot({ path: path.join(out, 'cpl-recruiter-reel-poster.png'), type: 'png' });
console.log(JSON.stringify(result));
await browser.close();
await new Promise(resolve => server.close(resolve));
